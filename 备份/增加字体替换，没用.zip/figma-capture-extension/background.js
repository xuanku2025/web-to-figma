const WORLD = "ISOLATED";
const CAPTURE_FILE = "capture.js";
const RUNNER_FILE = "runner.js";
const TOOLBAR_FILE = "inpage-toolbar.js";
const FONT_MAP_FILE = "font-map.json";

const FIGMA_CAPTURE_CONCURRENCY_KEY = "proxyFetchConcurrency";
const FIGMA_CAPTURE_ALLOWED_CONCURRENCY = new Set([4, 6, 8, 10, 12, 16, 20]);
const FIGMA_CAPTURE_DEFAULT_CONCURRENCY = 8;
const FIGMA_CAPTURE_PROXY_SESSION_KEY = "figmaCaptureProxyAssetCacheV1";
const FIGMA_CAPTURE_PROXY_DIAG_KEY = "figmaCaptureProxyDiagnosticsV1";
const FIGMA_CAPTURE_PROXY_MAX_DIAG = 500;
const FIGMA_CAPTURE_FETCH_TIMEOUT_MS = 8000;
const FIGMA_CAPTURE_PROXY_CACHE_TTL_MS = 30 * 60 * 1000;
const FIGMA_CAPTURE_FONT_MAP_KEY = "fontFamilyMap";

const figmaProxyQueue = [];
const figmaProxyInFlight = new Map();
const figmaProxyMemCache = new Map();
let figmaProxyActive = 0;
let figmaProxyMaxConcurrency = FIGMA_CAPTURE_DEFAULT_CONCURRENCY;
let figmaProxyAdaptivePenalty = 0;
let figmaProxySessionLoaded = false;
let figmaProxySessionCache = {};
let figmaProxyDiagnostics = [];
let figmaFontMap = null;
let figmaLastCaptureDiagnostics = null;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function now() {
  return Date.now();
}

function isFiniteConcurrency(value) {
  return Number.isFinite(value);
}

function getEffectiveConcurrency() {
  if (!isFiniteConcurrency(figmaProxyMaxConcurrency)) return Number.POSITIVE_INFINITY;
  return Math.max(1, figmaProxyMaxConcurrency - figmaProxyAdaptivePenalty);
}

function normalizeConcurrency(value) {
  if (value === "infinite" || value === "∞") {
    return Number.POSITIVE_INFINITY;
  }
  const numeric = Number(value);
  if (FIGMA_CAPTURE_ALLOWED_CONCURRENCY.has(numeric)) {
    return numeric;
  }
  return FIGMA_CAPTURE_DEFAULT_CONCURRENCY;
}

function configuredConcurrencyLabel() {
  return isFiniteConcurrency(figmaProxyMaxConcurrency)
    ? String(figmaProxyMaxConcurrency)
    : "infinite";
}

function effectiveConcurrencyLabel() {
  const effective = getEffectiveConcurrency();
  return isFiniteConcurrency(effective) ? String(effective) : "infinite";
}

async function injectScriptFile(tabId, file) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: WORLD,
    files: [file],
  });
}

async function runCapture(tabId) {
  await injectScriptFile(tabId, CAPTURE_FILE);
  await sleep(300);
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: WORLD,
    files: [RUNNER_FILE],
  });
  return result;
}

function saveResult(result) {
  const text = JSON.stringify(result, null, 2);
  const url = URL.createObjectURL(new Blob([text], { type: "application/json" }));
  const filename = `figma-capture-${Date.now()}.json`;
  chrome.downloads.download({ url, filename, saveAs: true }, () => {
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  });
}

function saveDiagnostics(result) {
  const text = JSON.stringify(result, null, 2);
  const url = URL.createObjectURL(new Blob([text], { type: "application/json" }));
  const filename = `figma-capture-diagnostics-${Date.now()}.json`;
  chrome.downloads.download({ url, filename, saveAs: true }, () => {
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  });
}

function pushDiag(entry) {
  figmaProxyDiagnostics.push({ ts: now(), ...entry });
  if (figmaProxyDiagnostics.length > FIGMA_CAPTURE_PROXY_MAX_DIAG) {
    figmaProxyDiagnostics = figmaProxyDiagnostics.slice(-FIGMA_CAPTURE_PROXY_MAX_DIAG);
  }
  if (chrome?.storage?.session) {
    chrome.storage.session
      .set({ [FIGMA_CAPTURE_PROXY_DIAG_KEY]: figmaProxyDiagnostics })
      .catch(() => {});
  }
}

async function loadConcurrencyConfig() {
  try {
    const data = await chrome.storage.local.get({
      [FIGMA_CAPTURE_CONCURRENCY_KEY]: String(FIGMA_CAPTURE_DEFAULT_CONCURRENCY),
    });
    figmaProxyMaxConcurrency = normalizeConcurrency(data?.[FIGMA_CAPTURE_CONCURRENCY_KEY]);
  } catch {
    figmaProxyMaxConcurrency = FIGMA_CAPTURE_DEFAULT_CONCURRENCY;
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  if (changes?.[FIGMA_CAPTURE_CONCURRENCY_KEY]) {
    figmaProxyMaxConcurrency = normalizeConcurrency(
      changes[FIGMA_CAPTURE_CONCURRENCY_KEY].newValue
    );
    pumpProxyQueue();
  }

  if (changes?.[FIGMA_CAPTURE_FONT_MAP_KEY]) {
    figmaFontMap = null;
  }
});

async function loadProxySession() {
  if (figmaProxySessionLoaded) return;
  figmaProxySessionLoaded = true;
  if (!chrome?.storage?.session) return;
  try {
    const data = await chrome.storage.session.get({
      [FIGMA_CAPTURE_PROXY_SESSION_KEY]: {},
      [FIGMA_CAPTURE_PROXY_DIAG_KEY]: [],
    });
    figmaProxySessionCache = data?.[FIGMA_CAPTURE_PROXY_SESSION_KEY] || {};
    figmaProxyDiagnostics = Array.isArray(data?.[FIGMA_CAPTURE_PROXY_DIAG_KEY])
      ? data[FIGMA_CAPTURE_PROXY_DIAG_KEY]
      : [];
  } catch {
    figmaProxySessionCache = {};
    figmaProxyDiagnostics = [];
  }
}

async function persistProxySession() {
  if (!chrome?.storage?.session) return;
  try {
    await chrome.storage.session.set({
      [FIGMA_CAPTURE_PROXY_SESSION_KEY]: figmaProxySessionCache,
      [FIGMA_CAPTURE_PROXY_DIAG_KEY]: figmaProxyDiagnostics,
    });
  } catch {
    // no-op
  }
}

function enqueueProxyTask(task) {
  return new Promise((resolve, reject) => {
    figmaProxyQueue.push({ task, resolve, reject });
    pumpProxyQueue();
  });
}

function pumpProxyQueue() {
  const max = getEffectiveConcurrency();
  while (figmaProxyActive < max && figmaProxyQueue.length) {
    const item = figmaProxyQueue.shift();
    figmaProxyActive++;
    Promise.resolve()
      .then(item.task)
      .then(item.resolve, item.reject)
      .finally(() => {
        figmaProxyActive--;
        pumpProxyQueue();
      });
  }
}

function toBase64(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let binary = "";
  const chunk = 32768;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function isRetryableStatus(status) {
  return status === 429 || (status >= 500 && status <= 599);
}

function cacheEntryValid(entry) {
  return (
    entry &&
    typeof entry.base64 === "string" &&
    typeof entry.contentType === "string" &&
    typeof entry.expiresAt === "number" &&
    entry.expiresAt > now()
  );
}

function registerProxyResultHealth(result) {
  if (result?.ok) {
    figmaProxyAdaptivePenalty = Math.max(0, figmaProxyAdaptivePenalty - 1);
    return;
  }
  if (!isFiniteConcurrency(figmaProxyMaxConcurrency)) return;
  figmaProxyAdaptivePenalty = Math.min(
    figmaProxyAdaptivePenalty + 1,
    Math.max(0, figmaProxyMaxConcurrency - 1)
  );
}

async function fetchAssetWithRetry(url) {
  const maxAttempts = 3;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), FIGMA_CAPTURE_FETCH_TIMEOUT_MS);
      let response;
      try {
        response = await fetch(url, {
          credentials: "omit",
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timer);
      }

      if (response.ok) {
        return { ok: true, response, attempt };
      }

      if (attempt < maxAttempts && isRetryableStatus(response.status)) {
        const backoff = 300 * 2 ** (attempt - 1) + Math.floor(Math.random() * 150);
        pushDiag({
          url,
          phase: "proxy-retry",
          ok: false,
          status: response.status,
          attempt,
          backoff,
        });
        await sleep(backoff);
        continue;
      }

      return {
        ok: false,
        status: response.status,
        error: `HTTP_${response.status}`,
        attempt,
      };
    } catch (error) {
      const message = String(error);
      if (attempt < maxAttempts) {
        const backoff = 300 * 2 ** (attempt - 1) + Math.floor(Math.random() * 150);
        pushDiag({
          url,
          phase: "proxy-retry",
          ok: false,
          status: 0,
          attempt,
          error: message,
          backoff,
        });
        await sleep(backoff);
        continue;
      }
      return { ok: false, status: 0, error: message, attempt };
    }
  }
  return { ok: false, status: 0, error: "UNREACHABLE", attempt: 3 };
}

async function proxyFetchAsset(url) {
  await loadProxySession();

  const fromMemory = figmaProxyMemCache.get(url);
  if (cacheEntryValid(fromMemory)) {
    pushDiag({ url, phase: "proxy-cache-memory", ok: true, status: 200 });
    const result = {
      ok: true,
      status: 200,
      cacheHit: "memory",
      contentType: fromMemory.contentType,
      base64: fromMemory.base64,
    };
    registerProxyResultHealth(result);
    return result;
  }

  const fromSession = figmaProxySessionCache[url];
  if (cacheEntryValid(fromSession)) {
    figmaProxyMemCache.set(url, fromSession);
    pushDiag({ url, phase: "proxy-cache-session", ok: true, status: 200 });
    const result = {
      ok: true,
      status: 200,
      cacheHit: "session",
      contentType: fromSession.contentType,
      base64: fromSession.base64,
    };
    registerProxyResultHealth(result);
    return result;
  }

  if (figmaProxyInFlight.has(url)) {
    return figmaProxyInFlight.get(url);
  }

  const promise = enqueueProxyTask(async () => {
    const fetched = await fetchAssetWithRetry(url);
    if (!fetched.ok) {
      pushDiag({
        url,
        phase: "proxy-fetch",
        ok: false,
        status: fetched.status,
        error: fetched.error,
        attempt: fetched.attempt,
      });
      const result = {
        ok: false,
        status: fetched.status,
        error: fetched.error,
        attempt: fetched.attempt,
      };
      registerProxyResultHealth(result);
      return result;
    }

    const contentType =
      fetched.response.headers.get("content-type") || "application/octet-stream";
    const base64 = toBase64(await fetched.response.arrayBuffer());
    const cacheEntry = {
      contentType,
      base64,
      expiresAt: now() + FIGMA_CAPTURE_PROXY_CACHE_TTL_MS,
    };
    figmaProxyMemCache.set(url, cacheEntry);
    figmaProxySessionCache[url] = cacheEntry;
    persistProxySession();

    pushDiag({
      url,
      phase: "proxy-fetch",
      ok: true,
      status: fetched.response.status,
      attempt: fetched.attempt,
      bytes: base64.length,
    });

    const result = {
      ok: true,
      status: fetched.response.status,
      contentType,
      base64,
      cacheHit: "miss",
      attempt: fetched.attempt,
    };
    registerProxyResultHealth(result);
    return result;
  }).finally(() => {
    figmaProxyInFlight.delete(url);
  });

  figmaProxyInFlight.set(url, promise);
  return promise;
}

function structuredCloneSafe(value) {
  if (typeof structuredClone === "function") {
    return structuredClone(value);
  }
  return JSON.parse(JSON.stringify(value));
}

function walkObject(obj, visitor, seen = new WeakSet()) {
  if (!obj || typeof obj !== "object") return;
  if (seen.has(obj)) return;
  seen.add(obj);
  visitor(obj);
  if (Array.isArray(obj)) {
    for (const item of obj) {
      walkObject(item, visitor, seen);
    }
    return;
  }
  for (const key of Object.keys(obj)) {
    walkObject(obj[key], visitor, seen);
  }
}

function getChildren(node) {
  if (!node || typeof node !== "object") return null;
  if (Array.isArray(node.children)) return node.children;
  if (Array.isArray(node.childNodes)) return node.childNodes;
  return null;
}

function hasVisualSignals(node) {
  if (!node || typeof node !== "object") return false;
  const visualKeys = [
    "background",
    "backgroundColor",
    "backgroundImage",
    "maskImage",
    "border",
    "boxShadow",
    "src",
    "fill",
    "stroke",
    "image",
    "assetKey",
    "rasterizedImageUrl",
    "opacity",
  ];
  return visualKeys.some((k) => node[k]);
}

function textValue(node) {
  if (!node || typeof node !== "object") return "";
  return String(
    node.text ?? node.textContent ?? node.characters ?? node.value ?? ""
  ).trim();
}

function isLikelyContainerTag(tag) {
  if (!tag) return true;
  const t = String(tag).toLowerCase();
  return ["div", "span", "section", "article", "main", "header", "footer"].includes(t);
}

function pruneAndFlatten(node, stats) {
  const children = getChildren(node);
  if (!children) return node;

  const next = [];
  for (let child of children) {
    child = pruneAndFlatten(child, stats);
    if (!child) continue;

    const childKids = getChildren(child);
    const childText = textValue(child);
    if (
      (!childKids || childKids.length === 0) &&
      !childText &&
      !hasVisualSignals(child)
    ) {
      stats.pruned += 1;
      continue;
    }

    next.push(child);
  }

  if (Array.isArray(node.children)) node.children = next;
  if (Array.isArray(node.childNodes)) node.childNodes = next;

  // Flatten one level of trivial wrappers.
  for (let i = 0; i < next.length; i++) {
    const child = next[i];
    const childChildren = getChildren(child);
    if (!childChildren || childChildren.length !== 1) continue;
    if (textValue(child)) continue;
    if (hasVisualSignals(child)) continue;
    if (!isLikelyContainerTag(child.tagName || child.name)) continue;

    next[i] = childChildren[0];
    stats.flattened += 1;
  }

  return node;
}

function dedupeFallbackList(parts) {
  const seen = new Set();
  const out = [];
  for (const raw of parts) {
    const key = raw.replace(/['"]/g, "").trim().toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(raw.trim());
  }
  return out;
}

function quoteIfNeeded(name) {
  const trimmed = String(name).trim();
  if (!trimmed) return trimmed;
  if (trimmed.startsWith("\"") || trimmed.startsWith("'")) return trimmed;
  if (/\s/.test(trimmed)) return `\"${trimmed}\"`;
  return trimmed;
}

function normalizeFontFamily(rawFamily, map) {
  const original = String(rawFamily || "").trim();
  const normalized = original.replace(/["']/g, "").trim();

  const iconLike = /(icon|font\s*awesome|material\s*icons|glyph|symbol)/i.test(
    normalized
  );
  const serifLike = /(serif|song|ming|times|georgia)/i.test(normalized);
  const mapped = map[normalized] || map[normalized.toLowerCase()] || normalized;

  if (iconLike) {
    const list = dedupeFallbackList([
      quoteIfNeeded(mapped),
      '"PingFang SC"',
      '"Microsoft YaHei"',
      "sans-serif",
    ]);
    return list.join(", ");
  }

  if (!mapped || /^times( new roman)?$/i.test(mapped)) {
    return serifLike
      ? '"Noto Serif CJK SC", "Source Han Serif SC", serif'
      : '"PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif';
  }

  const fallback = serifLike
    ? ['"Noto Serif CJK SC"', '"Source Han Serif SC"', "serif"]
    : ['"PingFang SC"', '"Microsoft YaHei"', '"Noto Sans CJK SC"', "sans-serif"];

  return dedupeFallbackList([quoteIfNeeded(mapped), ...fallback]).join(", ");
}

async function loadFontMap() {
  if (figmaFontMap) return figmaFontMap;

  let fileMap = {};
  try {
    const res = await fetch(chrome.runtime.getURL(FONT_MAP_FILE));
    if (res.ok) {
      fileMap = await res.json();
    }
  } catch {
    fileMap = {};
  }

  let userMap = {};
  try {
    const data = await chrome.storage.local.get({ [FIGMA_CAPTURE_FONT_MAP_KEY]: {} });
    userMap = data?.[FIGMA_CAPTURE_FONT_MAP_KEY] || {};
  } catch {
    userMap = {};
  }

  figmaFontMap = { ...fileMap, ...userMap };
  return figmaFontMap;
}

async function postProcessCapturePayload(payload) {
  const startedAt = now();
  const map = await loadFontMap();
  const result = structuredCloneSafe(payload);
  const root = result?.root || result;

  const fontStats = { touched: 0 };
  walkObject(root, (node) => {
    if (!node || typeof node !== "object") return;
    if (typeof node.fontFamily === "string") {
      const next = normalizeFontFamily(node.fontFamily, map);
      if (next && next !== node.fontFamily) {
        node.fontFamily = next;
        fontStats.touched += 1;
      }
    }
    if (node.style && typeof node.style.fontFamily === "string") {
      const next = normalizeFontFamily(node.style.fontFamily, map);
      if (next && next !== node.style.fontFamily) {
        node.style.fontFamily = next;
        fontStats.touched += 1;
      }
    }
  });

  const domStats = { pruned: 0, flattened: 0, passes: 0 };
  for (let i = 0; i < 3; i++) {
    domStats.passes += 1;
    pruneAndFlatten(root, domStats);
  }

  result.diagnostics = {
    ...(result.diagnostics || {}),
    postprocess: {
      version: "v1",
      durationMs: now() - startedAt,
      fontFixed: fontStats.touched,
      nodesPruned: domStats.pruned,
      nodesFlattened: domStats.flattened,
      passes: domStats.passes,
    },
  };

  return result;
}

async function getProxyDiagnosticsReport() {
  await loadProxySession();
  return {
    generatedAt: new Date().toISOString(),
    queueDepth: figmaProxyQueue.length,
    activeRequests: figmaProxyActive,
    inFlight: figmaProxyInFlight.size,
    configuredConcurrency: configuredConcurrencyLabel(),
    effectiveConcurrency: effectiveConcurrencyLabel(),
    adaptivePenalty: figmaProxyAdaptivePenalty,
    failures: figmaProxyDiagnostics.filter((x) => x && x.ok === false),
  };
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  try {
    await injectScriptFile(tab.id, TOOLBAR_FILE);
  } catch (error) {
    console.error("Toolbar inject failed:", error);
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "FIGMA_CAPTURE_START") return;
  (async () => {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tab = tabs && tabs[0];
      if (!tab?.id) {
        throw new Error("No active tab to capture");
      }
      const raw = await runCapture(tab.id);
      if (!raw) {
        throw new Error("Capture returned empty result");
      }

      const processed = await postProcessCapturePayload(raw);
      figmaLastCaptureDiagnostics = processed?.diagnostics || null;
      saveResult(processed);
      sendResponse({ ok: true });
    } catch (error) {
      console.error("Capture failed:", error);
      sendResponse({ ok: false, error: String(error) });
    }
  })();
  return true;
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "FIGMA_CAPTURE_FETCH_ASSET" || !msg.url) return;
  (async () => {
    const result = await proxyFetchAsset(msg.url);
    sendResponse({
      ...result,
      diagnostics: {
        phase: "proxy",
        cacheHit: result.cacheHit || null,
        queueDepth: figmaProxyQueue.length,
        activeRequests: figmaProxyActive,
        configuredConcurrency: configuredConcurrencyLabel(),
        effectiveConcurrency: effectiveConcurrencyLabel(),
      },
    });
  })();
  return true;
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "FIGMA_CAPTURE_GET_DIAGNOSTICS") return;
  (async () => {
    const diagnostics = await getProxyDiagnosticsReport();
    sendResponse({ ok: true, diagnostics });
  })();
  return true;
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "FIGMA_CAPTURE_EXPORT_DIAGNOSTICS") return;
  (async () => {
    const proxy = await getProxyDiagnosticsReport();
    const report = {
      generatedAt: new Date().toISOString(),
      proxy,
      lastCaptureDiagnostics: figmaLastCaptureDiagnostics,
    };
    saveDiagnostics(report);
    sendResponse({ ok: true });
  })();
  return true;
});

loadConcurrencyConfig();
loadFontMap();
