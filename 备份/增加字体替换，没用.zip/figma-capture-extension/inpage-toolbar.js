(() => {
  const ROOT_ID = "__figma_capture_toolbar__";
  const STYLE_ID = "__figma_capture_toolbar_style__";
  const TOOLBAR_FLAG = "__FIGMA_CAPTURE_TOOLBAR_INSTALLED__";
  const STORAGE_PROXY_KEY = "enableAssetProxyFetch";
  const STORAGE_CONCURRENCY_KEY = "proxyFetchConcurrency";
  const STORAGE_FONT_MAP_KEY = "fontFamilyMap";
  const DEFAULT_CONCURRENCY = "8";
  const ALLOWED = new Set(["4", "6", "8", "10", "12", "16", "20", "infinite"]);
  const DEFAULT_FONT_MAP = {
    Arial: "PingFang SC",
    Helvetica: "PingFang SC",
    "Helvetica Neue": "PingFang SC",
    "Times New Roman": "Noto Serif CJK SC",
    Georgia: "Noto Serif CJK SC",
    Roboto: "PingFang SC",
  };

  function normalize(value) {
    const str = String(value ?? "");
    return ALLOWED.has(str) ? str : DEFAULT_CONCURRENCY;
  }

  function removeExisting() {
    const oldRoot = document.getElementById(ROOT_ID);
    if (oldRoot) oldRoot.remove();
    const oldStyle = document.getElementById(STYLE_ID);
    if (oldStyle) oldStyle.remove();
    globalThis[TOOLBAR_FLAG] = false;
  }

  function createStyle() {
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${ROOT_ID} {
        position: fixed;
        top: 16px;
        right: 16px;
        width: 332px;
        z-index: 2147483647;
        border-radius: 12px;
        border: 1px solid #d0d7de;
        background: #ffffff;
        box-shadow: 0 8px 28px rgba(15, 23, 42, 0.2);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        color: #111827;
      }
      #${ROOT_ID} * { box-sizing: border-box; }
      #${ROOT_ID} .bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        border-bottom: 1px solid #e5e7eb;
      }
      #${ROOT_ID} .title { font-size: 13px; font-weight: 600; }
      #${ROOT_ID} .close {
        border: 0;
        background: transparent;
        cursor: pointer;
        color: #6b7280;
        font-size: 18px;
        line-height: 1;
      }
      #${ROOT_ID} .body { padding: 12px; display: grid; gap: 10px; }
      #${ROOT_ID} .row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        font-size: 13px;
      }
      #${ROOT_ID} select {
        min-width: 88px;
        padding: 4px 6px;
        border-radius: 8px;
        border: 1px solid #d1d5db;
        background: #fff;
      }
      #${ROOT_ID} .hint { font-size: 12px; color: #6b7280; margin: 0; }
      #${ROOT_ID} .actions { display: grid; gap: 8px; }
      #${ROOT_ID} details {
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 8px;
      }
      #${ROOT_ID} summary {
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        user-select: none;
      }
      #${ROOT_ID} .font-box {
        margin-top: 8px;
        display: grid;
        gap: 8px;
      }
      #${ROOT_ID} .mini-actions {
        display: flex;
        gap: 8px;
      }
      #${ROOT_ID} .font-rows {
        display: grid;
        gap: 6px;
      }
      #${ROOT_ID} .font-row {
        display: grid;
        grid-template-columns: 1fr 1fr auto;
        gap: 6px;
      }
      #${ROOT_ID} .font-row input {
        min-width: 0;
        border-radius: 8px;
        border: 1px solid #d1d5db;
        padding: 6px 8px;
        font-size: 12px;
      }
      #${ROOT_ID} .font-row .del {
        border: 1px solid #d1d5db;
        background: #fff;
        border-radius: 8px;
        padding: 0 10px;
        font-size: 12px;
        cursor: pointer;
      }
      #${ROOT_ID} .examples {
        margin: 0;
        padding-left: 16px;
        font-size: 12px;
        color: #4b5563;
        display: grid;
        gap: 4px;
      }
      #${ROOT_ID} .examples code {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 11px;
      }
      #${ROOT_ID} .mini-btn {
        flex: 1;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        font-size: 12px;
        background: #fff;
        color: #111827;
        padding: 7px 10px;
        cursor: pointer;
      }
      #${ROOT_ID} .capture,
      #${ROOT_ID} .diag {
        width: 100%;
        border: 0;
        border-radius: 8px;
        font-size: 13px;
        padding: 9px 12px;
        cursor: pointer;
      }
      #${ROOT_ID} .capture { background: #111827; color: #fff; }
      #${ROOT_ID} .diag { background: #eef2ff; color: #1f2937; }
      #${ROOT_ID} .status { min-height: 16px; margin: 0; font-size: 12px; color: #374151; }
      #${ROOT_ID} .hidden { display: none !important; }
    `;
    return style;
  }

  function createToolbar() {
    const root = document.createElement("section");
    root.id = ROOT_ID;
    root.setAttribute("data-figma-capture-ignore", "1");
    root.innerHTML = `
      <div class="bar" data-figma-capture-ignore="1">
        <div class="title" data-figma-capture-ignore="1">Web to Figma</div>
        <button class="close" type="button" title="关闭" data-figma-capture-ignore="1">×</button>
      </div>
      <div class="body" data-figma-capture-ignore="1">
        <label class="row" data-figma-capture-ignore="1">
          <span data-figma-capture-ignore="1">跨域图片代理模式</span>
          <input id="figmaProxyToggle" type="checkbox" data-figma-capture-ignore="1" />
        </label>
        <label class="row" id="figmaConcurrencyRow" data-figma-capture-ignore="1">
          <span data-figma-capture-ignore="1">图片采集并发</span>
          <select id="figmaProxyConcurrency" data-figma-capture-ignore="1">
            <option value="4">4</option>
            <option value="6">6</option>
            <option value="8">8</option>
            <option value="10">10</option>
            <option value="12">12</option>
            <option value="16">16</option>
            <option value="20">20</option>
            <option value="infinite">无限</option>
          </select>
        </label>
        <p class="hint" data-figma-capture-ignore="1">开启后由扩展后台代理拉取跨域图片，减少丢图。</p>
        <details data-figma-capture-ignore="1">
          <summary data-figma-capture-ignore="1">字体映射配置</summary>
          <div class="font-box" data-figma-capture-ignore="1">
            <div class="font-rows" id="figmaFontMapRows" data-figma-capture-ignore="1"></div>
            <ul class="examples" data-figma-capture-ignore="1">
              <li data-figma-capture-ignore="1">左边填网页原字体，右边填替换后的字体。</li>
              <li data-figma-capture-ignore="1">示例：Arial -> PingFang SC，Times New Roman -> Noto Serif CJK SC。</li>
              <li data-figma-capture-ignore="1">图标字体建议保持同名，例如 Font Awesome 6 Free -> Font Awesome 6 Free。</li>
            </ul>
            <div class="mini-actions" data-figma-capture-ignore="1">
              <button class="mini-btn" id="figmaFontMapAddBtn" type="button" data-figma-capture-ignore="1">新增一行</button>
              <button class="mini-btn" id="figmaFontMapSaveBtn" type="button" data-figma-capture-ignore="1">保存字体映射</button>
              <button class="mini-btn" id="figmaFontMapResetBtn" type="button" data-figma-capture-ignore="1">恢复示例</button>
            </div>
          </div>
        </details>
        <div class="actions" data-figma-capture-ignore="1">
          <button class="capture" id="figmaCaptureBtn" type="button" data-figma-capture-ignore="1">开始采集</button>
          <button class="diag" id="figmaDiagBtn" type="button" data-figma-capture-ignore="1">导出诊断</button>
          <p class="status" id="figmaCaptureStatus" aria-live="polite" data-figma-capture-ignore="1"></p>
        </div>
      </div>
    `;
    return root;
  }

  function setStatus(node, text) {
    node.textContent = text || "";
  }

  function syncProxyDependentUI(toggleNode, concurrencyRow) {
    concurrencyRow.classList.toggle("hidden", !toggleNode.checked);
  }

  function normalizeFontMap(input) {
    if (!input || typeof input !== "object" || Array.isArray(input)) return {};
    const out = {};
    for (const [rawFrom, rawTo] of Object.entries(input)) {
      const from = String(rawFrom || "").trim();
      const to = String(rawTo || "").trim();
      if (!from || !to) continue;
      out[from] = to;
    }
    return out;
  }

  function createFontRow(from = "", to = "") {
    const row = document.createElement("div");
    row.className = "font-row";
    row.setAttribute("data-figma-capture-ignore", "1");
    const fromInput = document.createElement("input");
    fromInput.className = "from";
    fromInput.type = "text";
    fromInput.placeholder = "原字体，如 Arial";
    fromInput.value = from;
    fromInput.setAttribute("data-figma-capture-ignore", "1");

    const toInput = document.createElement("input");
    toInput.className = "to";
    toInput.type = "text";
    toInput.placeholder = "替换字体，如 PingFang SC";
    toInput.value = to;
    toInput.setAttribute("data-figma-capture-ignore", "1");

    const delBtn = document.createElement("button");
    delBtn.className = "del";
    delBtn.type = "button";
    delBtn.textContent = "删除";
    delBtn.setAttribute("data-figma-capture-ignore", "1");

    row.appendChild(fromInput);
    row.appendChild(toInput);
    row.appendChild(delBtn);

    delBtn.addEventListener("click", () => {
      const parent = row.parentElement;
      row.remove();
      if (parent && !parent.children.length) {
        parent.appendChild(createFontRow());
      }
    });
    return row;
  }

  function renderFontRows(container, map) {
    container.innerHTML = "";
    const entries = Object.entries(normalizeFontMap(map));
    if (!entries.length) {
      container.appendChild(createFontRow());
      return;
    }
    for (const [from, to] of entries) {
      container.appendChild(createFontRow(from, to));
    }
  }

  function collectFontMapFromRows(container) {
    const out = {};
    const rows = container.querySelectorAll(".font-row");
    for (const row of rows) {
      const from = String(row.querySelector(".from")?.value || "").trim();
      const to = String(row.querySelector(".to")?.value || "").trim();
      if (!from || !to) continue;
      out[from] = to;
    }
    return out;
  }

  // Idempotent toggle behavior.
  if (globalThis[TOOLBAR_FLAG]) {
    removeExisting();
    return;
  }

  removeExisting();
  document.documentElement.appendChild(createStyle());
  const root = createToolbar();
  document.documentElement.appendChild(root);
  globalThis[TOOLBAR_FLAG] = true;

  const closeBtn = root.querySelector(".close");
  const toggle = root.querySelector("#figmaProxyToggle");
  const concurrency = root.querySelector("#figmaProxyConcurrency");
  const concurrencyRow = root.querySelector("#figmaConcurrencyRow");
  const captureBtn = root.querySelector("#figmaCaptureBtn");
  const diagBtn = root.querySelector("#figmaDiagBtn");
  const status = root.querySelector("#figmaCaptureStatus");
  const fontMapRows = root.querySelector("#figmaFontMapRows");
  const fontMapAddBtn = root.querySelector("#figmaFontMapAddBtn");
  const fontMapSaveBtn = root.querySelector("#figmaFontMapSaveBtn");
  const fontMapResetBtn = root.querySelector("#figmaFontMapResetBtn");

  closeBtn.addEventListener("click", () => {
    removeExisting();
  });

  chrome.storage.local.get(
    {
      [STORAGE_PROXY_KEY]: false,
      [STORAGE_CONCURRENCY_KEY]: DEFAULT_CONCURRENCY,
      [STORAGE_FONT_MAP_KEY]: {},
    },
    (res) => {
      toggle.checked = Boolean(res[STORAGE_PROXY_KEY]);
      concurrency.value = normalize(res[STORAGE_CONCURRENCY_KEY]);
      syncProxyDependentUI(toggle, concurrencyRow);

      const map = res[STORAGE_FONT_MAP_KEY];
      renderFontRows(fontMapRows, Object.keys(map || {}).length ? map : DEFAULT_FONT_MAP);
    }
  );

  toggle.addEventListener("change", () => {
    syncProxyDependentUI(toggle, concurrencyRow);
    chrome.storage.local.set({ [STORAGE_PROXY_KEY]: toggle.checked }, () => {
      setStatus(status, toggle.checked ? "已开启代理模式" : "已关闭代理模式");
    });
  });

  concurrency.addEventListener("change", () => {
    const value = normalize(concurrency.value);
    concurrency.value = value;
    chrome.storage.local.set({ [STORAGE_CONCURRENCY_KEY]: value }, () => {
      setStatus(status, `并发已设为：${value === "infinite" ? "无限" : value}`);
    });
  });

  fontMapAddBtn.addEventListener("click", () => {
    fontMapRows.appendChild(createFontRow());
  });

  fontMapSaveBtn.addEventListener("click", () => {
    const map = collectFontMapFromRows(fontMapRows);
    chrome.storage.local.set({ [STORAGE_FONT_MAP_KEY]: map }, () => {
      const err = chrome.runtime.lastError;
      if (err) {
        setStatus(status, `字体映射保存失败：${err.message}`);
        return;
      }
      renderFontRows(fontMapRows, map);
      setStatus(status, "字体映射已保存");
    });
  });

  fontMapResetBtn.addEventListener("click", () => {
    renderFontRows(fontMapRows, DEFAULT_FONT_MAP);
    setStatus(status, "已恢复示例，可直接保存生效");
  });

  captureBtn.addEventListener("click", () => {
    removeExisting();
    chrome.runtime.sendMessage({ type: "FIGMA_CAPTURE_START" }, (res) => {
      const err = chrome.runtime.lastError;
      if (err) {
        console.error("Capture failed:", err.message);
        return;
      }
      if (!res || !res.ok) {
        console.error("Capture failed:", (res && res.error) || "未知错误");
      }
    });
  });

  diagBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "FIGMA_CAPTURE_EXPORT_DIAGNOSTICS" }, (res) => {
      const err = chrome.runtime.lastError;
      if (err) {
        setStatus(status, `导出失败：${err.message}`);
        return;
      }
      if (!res || !res.ok) {
        setStatus(status, `导出失败：${(res && res.error) || "未知错误"}`);
        return;
      }
      setStatus(status, "诊断文件已开始下载。");
    });
  });
})();
